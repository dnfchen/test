create
    definer = root@localhost procedure sp_sale(IN c int)
BEGIN	
	declare stmt varchar(2000);
	set @sqlstr=concat("SELECT p.id AS id, p.name AS NAME,SUM(od.num) AS total ,SUM(od.num)*price AS money
	FROM order_detail od, product_info p 
	WHERE p.id=od.p_id 
	GROUP BY p.id,p.name,p.price ORDER BY total DESC LIMIT 1,",c);
     prepare stmt from @sqlstr;
     execute stmt;
    END;

